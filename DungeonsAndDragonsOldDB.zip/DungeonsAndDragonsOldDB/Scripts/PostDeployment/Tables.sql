﻿USE DungeonsAndDragonsOldDB
GO

INSERT INTO dbo.EpicDestinies(Name, FlavourText)
VALUES
	('Archmage', ''),
	('Deadly Trickster', ''),
	('Demigod', ''),
	('Eternal Seeker', '')
GO

--INSERT INTO dbo.ParagonPaths(Name, FlavourText)
--VALUES
--	('', '')
--GO
